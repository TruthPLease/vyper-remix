---
description: Quick Start For Wallets Using Kotlin Client \(Android\)
---

# Kotlin Client (Android)

## Quick Start For Wallets (Kotlin Client)

:::info
You can use the **Example Dapp** to test your integration at [example.walletconnect.org](https://example.walletconnect.org) \([Source code](https://github.com/WalletConnect/walletconnect-example-dapp)\)
:::

## Github

This quick start is currently incomplete, please check the [Github repository](https://github.com/WalletConnect/kotlin-walletconnect-lib) for this Client

