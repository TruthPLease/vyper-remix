---
description: Quick Start For Wallets Using Swift Client \(iOS\)
---

# Swift Client (iOS)

## Quick Start For Wallets (Swift Client)

:::info
You can use the **Example Dapp** to test your integration at [example.walletconnect.org](https://example.walletconnect.org) \([Source code](https://github.com/WalletConnect/walletconnect-example-dapp)\)
:::

## Github

This quick start is currently incomplete.

There are two swift clients available at the moment:

* [wallet-connect-swift](https://github.com/WalletConnect/wallet-connect-swift) maintained by [Trust Wallet](https://trustwallet.com) team
* [WalletConnectSwift](https://github.com/WalletConnect/WalletConnectSwift) maintained by [Gnosis Safe](https://gnosis-safe.io) team

Please check the repositories for more details.

